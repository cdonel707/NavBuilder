# Fern Nav Builder

A tool to automatically generate navigation structure for Fern documentation from markdown files.

## Installation

```bash
pip install fern-nav-builder
```

## Usage

```bash
fern-nav /path/to/pages/folder
```